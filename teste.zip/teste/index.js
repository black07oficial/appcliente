import 'core-js/actual/structured-clone';
import 'expo-router/entry';
import 'react-native-gesture-handler';
