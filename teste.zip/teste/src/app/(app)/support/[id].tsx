import TicketDetailScreen from '../../../features/support/screens/TicketDetailScreen';

export default TicketDetailScreen; 