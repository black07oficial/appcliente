import SupportScreen from '../../../features/support/screens/SupportScreen';

export default SupportScreen; 