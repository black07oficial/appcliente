import CreateTicketScreen from '../../../features/support/screens/CreateTicketScreen';

export default CreateTicketScreen; 