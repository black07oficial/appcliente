import UsersScreen from '@/features/users/screens/UsersScreen';

export default UsersScreen; 