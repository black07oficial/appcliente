import BaasScreen from '@/features/admin/screens/BaasScreen';

export default BaasScreen;
