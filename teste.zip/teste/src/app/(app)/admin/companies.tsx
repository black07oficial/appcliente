import { CompaniesScreen } from '@/features/companies/screens/CompaniesScreen';

export default CompaniesScreen;
