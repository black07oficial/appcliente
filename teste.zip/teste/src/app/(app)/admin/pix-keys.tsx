import PixKeysScreen from '@/features/pix-keys/screens/PixKeysScreen';

export default PixKeysScreen;
