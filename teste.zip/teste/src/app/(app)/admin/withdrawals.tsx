import { AdminWithdrawalsScreen } from '../../../features/withdrawals/screens/AdminWithdrawalsScreen';

export default AdminWithdrawalsScreen; 