import TaxCalculatorScreen from '../../../features/tax-calculator/screens/TaxCalculatorScreen';

export default TaxCalculatorScreen; 