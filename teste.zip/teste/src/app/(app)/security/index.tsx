import SecurityScreen from '../../../features/security/screens/SecurityScreen';

export default SecurityScreen; 