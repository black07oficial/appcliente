import TransactionsScreen from '@/features/transactions/screens/TransactionsScreen';
import React from 'react';

const TransactionsPageRoute = () => {
    return <TransactionsScreen />;
};

export default TransactionsPageRoute; 