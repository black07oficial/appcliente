import CreateTransactionScreen from '../../../features/transactions/screens/CreateTransactionScreen';

export default CreateTransactionScreen; 