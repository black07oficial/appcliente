import SignUpScreen from '../../features/authentication/screens/SignUpScreen';

export default SignUpScreen; 