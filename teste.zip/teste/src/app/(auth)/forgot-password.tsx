import ForgotPasswordScreen from '@/features/authentication/screens/ForgotPasswordScreen';

export default ForgotPasswordScreen;
