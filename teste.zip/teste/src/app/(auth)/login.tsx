import LoginScreen from '@/features/authentication/screens/LoginScreen';

export default LoginScreen;
