import ResetPasswordScreen from '@/features/authentication/screens/ResetPasswordScreen';

export default ResetPasswordScreen;
