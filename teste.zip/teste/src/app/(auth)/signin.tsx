import SignInScreen from '@/features/authentication/screens/SignInScreen';

export default SignInScreen;
