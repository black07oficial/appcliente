import { useRouter } from 'expo-router';
import React from 'react';
import {
  Dimensions,
  Image,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { KingPayLogo } from '../../../components/common/KingPayLogo';

export default function WelcomeScreen() {
  const router = useRouter();

  return (
    <SafeAreaView style={styles.page}>
      <View style={styles.container}>
        <View style={styles.header}>
          <KingPayLogo width={90} height={18} />
        </View>

        <View style={styles.taglineContainer}>
          <Text style={styles.taglineText}>
            Tudo que seu negócio precisa, em <Text style={styles.highlight}>um só lugar.</Text>
          </Text>
        </View>

        <Image
          source={require('../../../../../imagens/cards.png')}
          style={styles.cardImage}
          resizeMode="contain"
        />

        <View style={styles.buttonsContainer}>
          <TouchableOpacity style={styles.loginButton} onPress={() => router.push('/(auth)/signin')}>
            <Text style={styles.loginButtonText}>Fazer login</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.forgotPasswordButton} onPress={() => router.push('/(auth)/forgot-password')}>
            <Text style={styles.forgotPasswordText}>Esqueci minha senha</Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
}

const { width, height } = Dimensions.get('window');

const styles = StyleSheet.create({
  page: {
    flex: 1,
    backgroundColor: '#E9EAFE', // Fundo lavanda bem claro
  },
  container: {
    flex: 1,
    alignItems: 'center',
    paddingHorizontal: 24,
  },
  header: {
    width: '100%',
    paddingTop: 40,
    paddingBottom: 20,
    alignItems: 'flex-start',
  },
  taglineContainer: {
    marginTop: height * 0.05,
    width: '100%',
  },
  taglineText: {
    fontSize: 42,
    lineHeight: 54,
    color: '#2C2C5A', // Azul escuro
    fontWeight: '300',
  },
  highlight: {
    fontWeight: '600',
    color: '#2C2C5A',
  },
  cardImage: {
    width: width * 1.2,
    height: height * 0.4,
    marginTop: -height * 0.05,
  },
  buttonsContainer: {
    width: '100%',
    position: 'absolute',
    bottom: 40,
  },
  loginButton: {
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
    height: 56,
    backgroundColor: '#1A1AFF', // Azul vibrante
    borderRadius: 28,
    marginBottom: 16,
  },
  loginButtonText: {
    fontWeight: '600',
    fontSize: 16,
    color: '#FFFFFF',
  },
  forgotPasswordButton: {
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
    height: 56,
    borderWidth: 1.5,
    borderColor: '#D3DFFF', // Borda azul clara
    backgroundColor: 'transparent',
    borderRadius: 28,
  },
  forgotPasswordText: {
    fontWeight: '600',
    fontSize: 16,
    color: '#1A1AFF',
  },
});
