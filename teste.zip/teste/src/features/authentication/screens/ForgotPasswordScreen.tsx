import { authService } from '@/features/authentication/services/authService';
import { useRouter } from 'expo-router';
import { ArrowLeft } from 'lucide-react-native';
import React, { useState } from 'react';
import {
  Alert,
  Image,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';

export default function ForgotPasswordScreen() {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleResetPassword = async () => {
    setLoading(true);
    // Note: Supabase sends a magic link. For a code-based flow, this would
    // typically call a custom server endpoint to generate and send a code.
    // We'll simulate success and navigate to the code entry screen.
    const { error } = await authService.resetPasswordForEmail(email);
    setLoading(false);

    if (error) {
      Alert.alert('Erro', error.message);
    } else {
      // On success, navigate to the screen where the user enters the code
      router.push({ pathname: '/(auth)/reset-password', params: { email } });
    }
  };

  return (
    <SafeAreaView style={styles.page}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <ArrowLeft color="#000" size={28} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Esqueci a senha</Text>
        </View>
        <ScrollView
          contentContainerStyle={styles.scrollContainer}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.imageContainer}>
            <Image
              source={require('../../../../../imagens/obj3d2.png')}
              style={styles.image3d}
              resizeMode="contain"
            />
          </View>

          <View style={styles.formContainer}>
            <Text style={styles.title}>Recuperação de senha</Text>
            <Text style={styles.subtitle}>
              Informe seu e-mail cadastrado para receber as instruções de recuperação.
            </Text>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Seu email</Text>
              <View style={styles.inputWrapper}>
                <TextInput
                  style={styles.textInput}
                  value={email}
                  onChangeText={setEmail}
                  placeholder="joaodasilva@gmail.com"
                  placeholderTextColor="#9E9E9E"
                  keyboardType="email-address"
                  autoCapitalize="none"
                />
              </View>
            </View>
          </View>

          <View style={styles.buttonsContainer}>
            <TouchableOpacity style={styles.sendButton} onPress={handleResetPassword} disabled={loading}>
              <Text style={styles.sendButtonText}>{loading ? 'Enviando...' : 'Enviar'}</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  page: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,
    paddingTop: 50,
    paddingBottom: 20,
  },
  backButton: {
    position: 'absolute',
    left: 20,
    top: 50,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#000',
  },
  scrollContainer: {
    flexGrow: 1,
    paddingHorizontal: 24,
    paddingBottom: 40,
  },
  imageContainer: {
    alignItems: 'center',
    marginVertical: 30,
  },
  image3d: {
    width: 180,
    height: 180,
  },
  formContainer: {
    width: '100%',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
    textAlign: 'left',
  },
  subtitle: {
    fontSize: 16,
    color: '#666',
    textAlign: 'left',
    marginBottom: 30,
  },
  inputGroup: {
    marginBottom: 24,
  },
  inputLabel: {
    fontWeight: '500',
    fontSize: 16,
    color: '#333333',
    marginBottom: 12,
  },
  inputWrapper: {
    backgroundColor: '#F8F9FE',
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 12,
    height: 56,
    justifyContent: 'center',
    paddingHorizontal: 16,
  },
  textInput: {
    flex: 1,
    fontSize: 16,
    color: '#333333',
  },
  buttonsContainer: {
    width: '100%',
    marginTop: 20,
  },
  sendButton: {
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
    height: 56,
    backgroundColor: '#1A1AFF',
    borderRadius: 28,
  },
  sendButtonText: {
    fontWeight: '600',
    fontSize: 16,
    color: '#FFFFFF',
  },
});
