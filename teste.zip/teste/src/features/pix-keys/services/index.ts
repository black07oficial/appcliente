import { PixKeyService } from './pixKeyService';

export const pixKeyService = new PixKeyService();

export * from './pixKeyService';
