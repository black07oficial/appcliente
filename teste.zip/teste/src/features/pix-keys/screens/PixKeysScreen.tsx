import React from 'react';
import { View, Text } from 'react-native';

const PixKeysScreen = () => {
  return (
    <View>
      <Text>Tela de Chaves Pix (Admin)</Text>
    </View>
  );
};

export default PixKeysScreen;
