import React from 'react';
import { Text, View } from 'react-native';

const UsersScreen = () => {
  return (
    <View>
      <Text>Tela de Usuários (Admin)</Text>
      {/* TODO: Integrar dados reais mantendo design original */}
    </View>
  );
};

export { UsersScreen };
export default UsersScreen;
