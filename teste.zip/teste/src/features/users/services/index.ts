import { UserManagementService } from './userManagementService';

export const userManagementService = new UserManagementService();

export * from './userManagementService';
