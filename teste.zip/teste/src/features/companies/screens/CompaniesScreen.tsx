import React from 'react';
import { Text, View } from 'react-native';

const CompaniesScreen = () => {
  return (
    <View>
      <Text>Tela de Empresas (Admin)</Text>
      {/* TODO: Integrar dados reais dos endpoints /companies mantendo design original */}
    </View>
  );
};

export { CompaniesScreen };
export default CompaniesScreen;
