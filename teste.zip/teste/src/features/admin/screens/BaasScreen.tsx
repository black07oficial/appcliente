import React from 'react';
import { View, Text } from 'react-native';

const BaasScreen = () => {
  return (
    <View>
      <Text>Tela de BaaS (Admin)</Text>
    </View>
  );
};

export default BaasScreen;
