import { PaymentLinkService } from './paymentLinkService';

export const paymentLinkService = new PaymentLinkService();

export * from './paymentLinkService';
