Edge Functions
Name	URL	Created	Last updated	Deployments
transactions

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/transactions


26 May, 2025 11:05


24 days ago

13

withdrawals

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/withdrawals


26 May, 2025 11:05


2 months ago

8

ShopfyOrder

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/ShopfyOrder


26 May, 2025 11:05


2 months ago

8

handleSendWebhook

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/handleSendWebhook


26 May, 2025 11:05


2 months ago

8

company

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/company


26 May, 2025 11:05


2 months ago

8

products-shopfy

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/products-shopfy


26 May, 2025 11:05


2 months ago

8

createCheckout

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/createCheckout


26 May, 2025 11:05


2 months ago

8

customers

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/customers


26 May, 2025 11:05


2 months ago

8

balance

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/balance


26 May, 2025 11:05


2 months ago

8

anticipation

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/anticipation


26 May, 2025 11:05


2 months ago

8

handleAsaasWebhookBaas

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/handleAsaasWebhookBaas


26 May, 2025 11:05


2 months ago

8

handleTransfeeraWebhookBaas

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/handleTransfeeraWebhookBaas


26 May, 2025 11:05


2 months ago

8

webhook_pagarme

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhook_pagarme


26 May, 2025 11:05


2 months ago

8

webhook_estorno

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhook_estorno


26 May, 2025 11:05


2 months ago

8

webhookMediusPag

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookMediusPag


26 May, 2025 11:05


2 months ago

8

webhookOwen

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookOwen


26 May, 2025 11:05


2 months ago

8

sendTransactionalEmails

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/sendTransactionalEmails


26 May, 2025 11:05


2 months ago

8

pixelFacebook

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/pixelFacebook


26 May, 2025 11:05


2 months ago

8

webhookAbmex

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookAbmex


26 May, 2025 11:05


2 months ago

8

webhookAsaas

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookAsaas


26 May, 2025 11:05


2 months ago

8

webhookPrimePag

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookPrimePag


26 May, 2025 11:05


2 months ago

8

webhookIugu

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookIugu


26 May, 2025 11:05


2 months ago

8

webhookTransfeeraTransaction

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookTransfeeraTransaction


26 May, 2025 11:05


2 months ago

8

webhookSnakePay

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookSnakePay


26 May, 2025 11:05


2 months ago

8

taxas

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/taxas


26 May, 2025 11:05


2 months ago

8

webhookFivePay

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookFivePay


26 May, 2025 11:05


2 months ago

8

webhookVoluti

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookVoluti


26 May, 2025 11:05


2 months ago

8

webhookWeMax

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookWeMax


26 May, 2025 11:05


2 months ago

8

webhookArmPay

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookArmPay


26 May, 2025 11:05


2 months ago

8

webhookGlobalChargebackVisa

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookGlobalChargebackVisa


26 May, 2025 11:05


2 months ago

8

webhookGlobalChargebackMasterCard

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookGlobalChargebackMasterCard


26 May, 2025 11:05


2 months ago

8

wallet

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/wallet


26 May, 2025 11:06


2 months ago

8

antecipacoes

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/antecipacoes


26 May, 2025 11:06


2 months ago

8

companies

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/companies


26 May, 2025 11:06


20 days ago

11

users

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/users


26 May, 2025 11:06


2 months ago

12

webhookVolutiTransaction

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookVolutiTransaction


26 May, 2025 11:06


2 months ago

8

webhookUltraPayments

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookUltraPayments


26 May, 2025 11:06


2 months ago

8

webhookMidasPay

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookMidasPay


26 May, 2025 11:06


2 months ago

8

webhookArmPayV2

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookArmPayV2


26 May, 2025 11:06


2 months ago

8

webhookPagouAi

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookPagouAi


26 May, 2025 11:06


2 months ago

8

webhookDubPay

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookDubPay


26 May, 2025 11:06


2 months ago

8

webhookCupulaHub

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookCupulaHub


26 May, 2025 11:06


2 months ago

8

acquirers

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/acquirers


26 May, 2025 11:06


2 months ago

8

gatewayConfig

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/gatewayConfig


26 May, 2025 11:06


2 months ago

8

extrato

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/extrato


26 May, 2025 11:06


2 months ago

8

baas

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/baas


26 May, 2025 11:06


2 months ago

8

transacoes

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/transacoes


26 May, 2025 11:06


2 months ago

8

saques

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/saques


26 May, 2025 11:06


2 months ago

8

dados-dashboard

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/dados-dashboard


26 May, 2025 11:06


17 days ago

31

faturamento-whitelabel

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/faturamento-whitelabel


26 May, 2025 11:06


2 months ago

8

whitelabel-financeiro

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/whitelabel-financeiro


26 May, 2025 11:06


2 months ago

8

pix-key

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/pix-key


26 May, 2025 11:07


2 months ago

8

webhook

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhook


26 May, 2025 11:07


2 months ago

8

billings

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/billings


26 May, 2025 11:07


2 months ago

8

configuracoes

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/configuracoes


26 May, 2025 11:07


2 months ago

8

alerts

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/alerts


26 May, 2025 11:07


2 months ago

8

clientes

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/clientes


26 May, 2025 11:07


2 months ago

8

standard

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/standard


26 May, 2025 11:07


2 months ago

8

risk

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/risk


26 May, 2025 11:07


2 months ago

8

webhookVilletPay

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookVilletPay


26 May, 2025 11:07


2 months ago

8

webhookSafe2pay

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookSafe2pay


26 May, 2025 11:07


2 months ago

8

webhookPronttus

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookPronttus


26 May, 2025 11:07


2 months ago

8

webhookArkama

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookArkama


26 May, 2025 11:07


2 months ago

8

subconta

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/subconta


26 May, 2025 11:07


2 months ago

8

webhookPlugouAi

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookPlugouAi


26 May, 2025 11:07


2 months ago

8

webhookPagueSafe

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookPagueSafe


26 May, 2025 11:07


2 months ago

8

webhookKingCash

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookKingCash


26 May, 2025 11:07


2 months ago

8

webhookAldoc

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookAldoc


26 May, 2025 11:07


2 months ago

8

webhookCashtime

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookCashtime


26 May, 2025 11:07


2 months ago

8

webhookFirebank

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookFirebank


26 May, 2025 11:07


2 months ago

8

webhookNacionalPag

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookNacionalPag


26 May, 2025 11:07


2 months ago

8

personalization

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/personalization


26 May, 2025 11:07


2 months ago

8

webhookPaymentsFlex

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookPaymentsFlex


26 May, 2025 11:07


2 months ago

8

webhookKount

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookKount


26 May, 2025 11:07


2 months ago

8

webhookPlugouAiV2

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookPlugouAiV2


26 May, 2025 11:07


2 months ago

8

link-pagamentos

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/link-pagamentos


26 May, 2025 11:07


2 months ago

9

webhookPagHubSub

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookPagHubSub


26 May, 2025 11:07


2 months ago

8

webhookIupiPay

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookIupiPay


26 May, 2025 11:07


2 months ago

8

webhookCommerceGate

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookCommerceGate


26 May, 2025 11:07


2 months ago

8

pixelTracker

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/pixelTracker


26 May, 2025 11:07


2 months ago

8

audit-log

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/audit-log


26 May, 2025 11:08


2 months ago

8

appNotifications

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/appNotifications


26 May, 2025 11:08


2 months ago

8

webhookpixium

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookpixium


26 May, 2025 11:08


2 months ago

8

webhookMutual

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookMutual


26 May, 2025 11:08


2 months ago

8

validation-codes

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/validation-codes


26 May, 2025 11:08


2 months ago

8

config-companie-view

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/config-companie-view


26 May, 2025 11:08


2 months ago

8

check-transaction-status

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/check-transaction-status


26 May, 2025 11:08


2 months ago

8

webhook-receiver

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhook-receiver


26 May, 2025 11:08


2 months ago

8

webhookhorizon

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookhorizon


26 May, 2025 11:08


2 months ago

9

tokenize

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/tokenize


26 May, 2025 11:08


2 months ago

8

credentials

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/credentials


26 May, 2025 11:08


2 months ago

8

hello-name

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/hello-name


26 May, 2025 12:38


2 months ago

8

link-pagamento-view

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/link-pagamento-view


28 May, 2025 20:56


2 months ago

8

support-tickets

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/support-tickets


06 Jun, 2025 18:39


a month ago

30

webhookcelcoin

https://slsikrvjbpblioyinsxu.supabase.co/functions/v1/webhookcelcoin


30 Jun, 2025 13:10


21 days ago

1

